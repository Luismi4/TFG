package com.example.pideloya;

public class AppConfig {
    // La URL base del servidor
    private static final String BASE_URL = "http://192.168.0.21/tf_bares/apirest/";

    // Método para obtener la URL base actual
    public static String getBaseUrl() {
        return BASE_URL;
    }
}

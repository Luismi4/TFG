package com.example.pideloya;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class leerQR extends AppCompatActivity {

    Button btnScan;
    String qrContent; // Variable para almacenar el contenido del QR
    private MTraerBarCartaSConID traerBarCartaSConID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leerqr);

        btnScan = findViewById(R.id.btnscan);
        traerBarCartaSConID = new MTraerBarCartaSConID(this);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator inte = new IntentIntegrator(leerQR.this);
                inte.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                inte.setPrompt("Lector - QR");
                inte.setCameraId(0);
                inte.setBeepEnabled(true);
                inte.setBarcodeImageEnabled(true);
                inte.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Lectura cancelada", Toast.LENGTH_SHORT).show();
            } else {
                qrContent = result.getContents(); // Guarda el contenido del QR en la variable
                Toast.makeText(this, qrContent, Toast.LENGTH_SHORT).show();

                // Procesar el contenido del QR
                String[] parts = qrContent.split(" ");
                if (parts.length == 2) {
                    String[] barPart = parts[0].split("=");
                    String[] mesaPart = parts[1].split("=");

                    if (barPart.length == 2 && mesaPart.length == 2) {
                        String idBar = barPart[1];
                        String idMesa = mesaPart[1];

                        // Crear objeto MesaBarId y utilizarlo según sea necesario
                        MesaBarId mesaBarId = new MesaBarId(idMesa, idBar);

                        // Llamar a la clase MtraerBarCartaSConID y almacenar el bar y la carta
                        traerBarCartaSConID.traerDatosDesdeServidorPorID(idBar);

                        // Ejemplo de uso: pasando la instancia a otra actividad
                        Intent intent = new Intent(leerQR.this, pedirActivity.class);
                        intent.putExtra("MesaBarId", mesaBarId);
                        startActivity(intent);

                    } else {
                        Toast.makeText(this, "Formato QR incorrecto", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Formato QR incorrecto", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}

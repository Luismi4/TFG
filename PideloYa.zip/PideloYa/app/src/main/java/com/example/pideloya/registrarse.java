package com.example.pideloya;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class registrarse extends AppCompatActivity {

    EditText etNombre, etUsuario, etCorreo, etDNI, etContrasena;
    Button btnRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);

        etNombre = findViewById(R.id.editTextNombre);
        etUsuario = findViewById(R.id.editTextUsuario);
        etCorreo = findViewById(R.id.correo);
        etDNI = findViewById(R.id.editTextDNI);
        etContrasena = findViewById(R.id.editTextContrasena);
        btnRegistrar = findViewById(R.id.buttonRegistrar);

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = etNombre.getText().toString();
                String usuario = etUsuario.getText().toString();
                String correo = etCorreo.getText().toString();
                String dni = etDNI.getText().toString();
                String contrasena = etContrasena.getText().toString();

                if (AppConfig.getBaseUrl() != null) {
                    enviarDatosRegistro(nombre, usuario, correo, dni, contrasena);
                } else {
                    Toast.makeText(getApplicationContext(), "No se pudo obtener la URL base. Intente nuevamente.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void enviarDatosRegistro(String nombre, String usuario, String correo, String dni, String contrasena) {
        RequestQueue queue = Volley.newRequestQueue(this);
        JSONObject postData = new JSONObject();
        try {
            postData.put("Nombre", nombre);
            postData.put("Usuario", usuario);
            postData.put("Correo", correo);
            postData.put("DNI", dni);
            postData.put("Contrasena", contrasena);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = AppConfig.getBaseUrl() + "insertar_usuario.php";
        Log.d("PostURL", url);
        Log.d("PostData", postData.toString());

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.has("success")) {
                                Toast.makeText(getApplicationContext(), "Usuario registrado correctamente", Toast.LENGTH_SHORT).show();
                            } else if (response.has("error")) {
                                Toast.makeText(getApplicationContext(), response.getString("error"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Error en el formato JSON", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("VolleyError", error.toString());
                        Toast.makeText(getApplicationContext(), "Error de conexión. Verifica tu conexión a Internet.", Toast.LENGTH_SHORT).show();
                    }
                });

        request.setRetryPolicy(new DefaultRetryPolicy(
                10000,  // Tiempo de espera inicial en ms
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,  // Número de reintentos
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));  // Factor de aumento de tiempo de espera

        queue.add(request);
    }
}

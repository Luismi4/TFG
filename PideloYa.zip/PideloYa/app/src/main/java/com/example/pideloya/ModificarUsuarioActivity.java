package com.example.pideloya;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ModificarUsuarioActivity extends AppCompatActivity {

    public RequestQueue requestQueue;
    EditText etNombre;
    EditText etCorreo;
    EditText etDNI;
    EditText etContrasena;
    Button btnModificar;
    AppConfig appConfig;
    usuarioID usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_usuario);

        // Inicializa los elementos
        etNombre = findViewById(R.id.etNombre);
        etCorreo = findViewById(R.id.etCorreo);
        etDNI = findViewById(R.id.etDNI);
        etContrasena = findViewById(R.id.etContrasena);
        btnModificar = findViewById(R.id.btnModificar);

        // Obtén el usuarioID del intent
        usuario = (usuarioID) getIntent().getSerializableExtra("usuarioID");

        // Verifica que usuario no sea null
        if (usuario != null) {
            // Mostrar un Toast con el ID del usuario
            Toast.makeText(this, "Usuario ID: " + usuario.getId(), Toast.LENGTH_LONG).show();

            // Obtener los datos actuales del usuario
            obtenerDatosUsuario(usuario.getId()); // Pasa el ID del usuario a la función
        } else {
            Toast.makeText(this, "Error: Usuario no encontrado", Toast.LENGTH_SHORT).show();
            finish(); // Termina la actividad si usuario es null
        }

        // Listener para el botón "Modificar"
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llama a la función para modificar los datos del usuario
                modificarDatosUsuario();
            }
        });
    }

    private void obtenerDatosUsuario(int idUsuario) {
        String url = appConfig.getBaseUrl() + "obtener_usuario.php"; // URL del endpoint PHP para obtener datos del usuario

        JSONObject postData = new JSONObject();
        try {
            postData.put("idUsuario", idUsuario);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.has("success")) {
                                JSONObject usuarioData = response.getJSONObject("usuario");
                                etNombre.setText(usuarioData.getString("Nombre"));
                                etCorreo.setText(usuarioData.getString("Correo"));
                                etDNI.setText(usuarioData.getString("DNI"));
                                etContrasena.setText(usuarioData.getString("Contrasena"));
                            } else if (response.has("error")) {
                                Toast.makeText(ModificarUsuarioActivity.this, response.getString("error"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(ModificarUsuarioActivity.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("ObtenerUsuario", "Error al obtener los datos del usuario: " + error.getMessage());
                        Toast.makeText(ModificarUsuarioActivity.this, "Error al obtener los datos del usuario", Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(request);
    }



    public void modificarDatosUsuario() {
        String url = appConfig.getBaseUrl() + "modificar_usuario.php"; // URL del endpoint PHP

        // Obtener los nuevos datos del usuario de los EditText
        String nombre = etNombre.getText().toString();
        String correo = etCorreo.getText().toString();
        String dni = etDNI.getText().toString();
        String contrasena = etContrasena.getText().toString();

        // Validar que los campos no estén vacíos
        if (nombre.isEmpty() || correo.isEmpty() || dni.isEmpty() || contrasena.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Objeto JSON para enviar los nuevos datos del usuario
        JSONObject postData = new JSONObject();
        try {
            postData.put("idUsuario", usuario.getId());
            postData.put("Nombre", nombre);
            postData.put("Correo", correo);
            postData.put("DNI", dni);
            postData.put("Contrasena", contrasena);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Realizar la solicitud HTTP POST utilizando Volley
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.has("success")) {
                                String mensaje = response.getString("success");
                                Toast.makeText(ModificarUsuarioActivity.this, mensaje, Toast.LENGTH_SHORT).show();
                                // Opcional: puedes regresar a la pantalla principal o realizar otra acción aquí
                                Intent intent = new Intent(ModificarUsuarioActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else if (response.has("error")) {
                                String error = response.getString("error");
                                Toast.makeText(ModificarUsuarioActivity.this, error, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(ModificarUsuarioActivity.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("ModificarUsuario", "Error al modificar los datos del usuario: " + error.getMessage());
                        Toast.makeText(ModificarUsuarioActivity.this, "Error al modificar los datos del usuario", Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(request);
    }
}

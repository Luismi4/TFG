package com.example.pideloya;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PedidoManager {
    private static final String TAG = PedidoManager.class.getSimpleName();
    private Context mContext;
    private RequestQueue mRequestQueue;

    public PedidoManager(Context context) {
        mContext = context.getApplicationContext(); // Use getApplicationContext() to avoid memory leaks
        mRequestQueue = Volley.newRequestQueue(mContext);
    }

    public void enviarPedidoDesdeSQLite(String url) {
        // Obtener una instancia de la base de datos SQLite en modo lectura
        SQLiteDatabase mDatabase = mContext.openOrCreateDatabase("locales.db", Context.MODE_PRIVATE, null);

        // Consultar los pedidos en la base de datos SQLite
        Cursor cursor = mDatabase.rawQuery("SELECT * FROM pedidos", null);

        if (cursor != null && cursor.moveToFirst()) {
            try {
                JSONArray jsonArray = new JSONArray(); // Crear un JSONArray para almacenar los pedidos

                do {
                    // Crear un objeto JSONObject para cada pedido
                    JSONObject jsonPedido = new JSONObject();
                    jsonPedido.put("id_mesa", cursor.getInt(cursor.getColumnIndex("id_mesa")));
                    jsonPedido.put("fecha_pedido", cursor.getString(cursor.getColumnIndex("fecha_pedido")));
                    jsonPedido.put("plato_1", cursor.getString(cursor.getColumnIndex("plato_1")));
                    jsonPedido.put("cantidad_plato_1", cursor.getInt(cursor.getColumnIndex("cantidad_plato_1")));
                    jsonPedido.put("plato_2", cursor.getString(cursor.getColumnIndex("plato_2")));
                    jsonPedido.put("cantidad_plato_2", cursor.getInt(cursor.getColumnIndex("cantidad_plato_2")));
                    jsonPedido.put("bebida_1", cursor.getString(cursor.getColumnIndex("bebida_1")));
                    jsonPedido.put("cantidad_bebida_1", cursor.getInt(cursor.getColumnIndex("cantidad_bebida_1")));
                    jsonPedido.put("bebida_2", cursor.getString(cursor.getColumnIndex("bebida_2")));
                    jsonPedido.put("cantidad_bebida_2", cursor.getInt(cursor.getColumnIndex("cantidad_bebida_2")));

                    // Agregar el pedido al JSONArray
                    jsonArray.put(jsonPedido);
                } while (cursor.moveToNext());

                // Enviar el JSONArray al servidor
                enviarPedidos(jsonArray, url);
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                cursor.close(); // Cerrar el cursor después de su uso
                mDatabase.close(); // Cerrar la conexión a la base de datos después de su uso
            }
        }
    }

    private void enviarPedidos(JSONArray jsonArray, String url) {
        try {
            // Crear un objeto JSON que contenga el JSONArray
            JSONObject requestBody = new JSONObject();
            requestBody.put("pedidos", jsonArray);

            // Crear la solicitud HTTP POST con el JSONObject como cuerpo
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, requestBody,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Manejar la respuesta del servidor si es necesario
                            Log.d(TAG, "Respuesta del servidor: " + response.toString());
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // Manejar errores de la petición
                            Log.e(TAG, "Error en la petición: " + error.toString());
                        }
                    });

            // Agregar la solicitud a la cola de solicitudes
            mRequestQueue.add(request);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}

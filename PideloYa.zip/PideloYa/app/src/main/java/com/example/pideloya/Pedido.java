package com.example.pideloya;

public class Pedido {
    private int idMesa;
    private String fechaPedido;
    private String plato1;
    private int cantidadPlato1;
    private String plato2;
    private int cantidadPlato2;
    private String bebida1;
    private int cantidadBebida1;
    private String bebida2;
    private int cantidadBebida2;

    // Constructor
    public Pedido() {
    }

    // Métodos getter y setter para cada atributo

    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getPlato1() {
        return plato1;
    }

    public void setPlato1(String plato1) {
        this.plato1 = plato1;
    }

    public int getCantidadPlato1() {
        return cantidadPlato1;
    }

    public void setCantidadPlato1(int cantidadPlato1) {
        this.cantidadPlato1 = cantidadPlato1;
    }

    public String getPlato2() {
        return plato2;
    }

    public void setPlato2(String plato2) {
        this.plato2 = plato2;
    }

    public int getCantidadPlato2() {
        return cantidadPlato2;
    }

    public void setCantidadPlato2(int cantidadPlato2) {
        this.cantidadPlato2 = cantidadPlato2;
    }

    public String getBebida1() {
        return bebida1;
    }

    public void setBebida1(String bebida1) {
        this.bebida1 = bebida1;
    }

    public int getCantidadBebida1() {
        return cantidadBebida1;
    }

    public void setCantidadBebida1(int cantidadBebida1) {
        this.cantidadBebida1 = cantidadBebida1;
    }

    public String getBebida2() {
        return bebida2;
    }

    public void setBebida2(String bebida2) {
        this.bebida2 = bebida2;
    }

    public int getCantidadBebida2() {
        return cantidadBebida2;
    }

    public void setCantidadBebida2(int cantidadBebida2) {
        this.cantidadBebida2 = cantidadBebida2;
    }
}

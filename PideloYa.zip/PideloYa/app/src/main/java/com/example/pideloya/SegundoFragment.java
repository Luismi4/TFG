package com.example.pideloya;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SegundoFragment extends Fragment {

    private RecyclerView recyclerView;
    private ListAdapterPedido pedidoAdapter;
    private DBHelper dbHelper;

    public SegundoFragment() {
        // Required empty public constructor
    }

    public static SegundoFragment newInstance() {
        return new SegundoFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DBHelper(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_segundo, container, false);

        recyclerView = rootView.findViewById(R.id.listRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Obtener los pedidos de la base de datos
        List<ListElementPedido> pedidos = dbHelper.getAllPedidos();

        // Verificar si se recuperaron los pedidos correctamente
        if (pedidos != null && !pedidos.isEmpty()) {
            // Crear un adaptador y establecerlo en el RecyclerView
            pedidoAdapter = new ListAdapterPedido(pedidos, requireContext());
            recyclerView.setAdapter(pedidoAdapter);
        } else {
            // Si no se recuperaron pedidos, mostrar un mensaje o realizar alguna acción apropiada
        }

        return rootView;
    }
}


package com.example.pideloya;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PrimerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PrimerFragment extends Fragment implements ListAdapter.OnItemClickListener {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private RecyclerView recyclerView;
    private ListAdapter listAdapter;
    private Button btnBuscarBar;
    private Button btnLeerQR;
    private DBHelper dbHelper;

    private String mParam1;
    private String mParam2;

    public PrimerFragment() {
        // Required empty public constructor
    }

    public static PrimerFragment newInstance(String param1, String param2) {
        PrimerFragment fragment = new PrimerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        dbHelper = new DBHelper(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_primer, container, false);

        // Encuentra el RecyclerView en la vista inflada del fragmento
        recyclerView = rootView.findViewById(R.id.listRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Encuentra los botones en la vista inflada del fragmento
        btnBuscarBar = rootView.findViewById(R.id.btnBuscarBar);
        btnLeerQR = rootView.findViewById(R.id.btnLeerQR);

        // Configura los listeners para los botones
        btnBuscarBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inicia la actividad BuscarBarPorNombreActivity
                Intent intent = new Intent(requireContext(), BuscarBarPorNombreActivity.class);
                startActivity(intent);
            }
        });

        btnLeerQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para el botón "Leer Código QR"
                Intent intent = new Intent(requireContext(), leerQR.class);
                startActivity(intent);
            }
        });

        // Carga los elementos desde la base de datos
        List<ListElement> elements = dbHelper.getAllBars();

        // Crea un adaptador y establece en el RecyclerView
        listAdapter = new ListAdapter(elements, requireContext(), this);
        recyclerView.setAdapter(listAdapter);

        return rootView;
    }

    @Override
    public void onItemClick(ListElement item) {
        Intent intent = new Intent(requireContext(), leerQR.class);
        intent.putExtra("ListElement", item);
        startActivity(intent);
    }
}

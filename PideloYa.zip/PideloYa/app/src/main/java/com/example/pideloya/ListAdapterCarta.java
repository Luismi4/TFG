package com.example.pideloya;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListAdapterCarta extends RecyclerView.Adapter<ListAdapterCarta.ViewHolder> {

    private List<ListElementCarta> mData;
    private LayoutInflater mInflater;
    private RecyclerView mRecyclerView;

    public ListAdapterCarta(List<ListElementCarta> itemList, Context context, RecyclerView recyclerView) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = itemList;
        this.mRecyclerView = recyclerView;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.lista_carta, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ListElementCarta carta = mData.get(position);
        holder.bindData(carta);
    }

    public EditText getEditTextQuantity(int position) {
        ViewHolder holder = (ViewHolder) mRecyclerView.findViewHolderForAdapterPosition(position);
        if (holder != null) {
            return holder.unidades;
        }
        return null;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView producto, precio;
        EditText unidades;

        ViewHolder(View itemView) {
            super(itemView);
            producto = itemView.findViewById(R.id.textViewProduct);
            precio = itemView.findViewById(R.id.textViewPrice);
            unidades = itemView.findViewById(R.id.editTextQuantity1);
        }

        void bindData(final ListElementCarta item) {
            producto.setText(item.getProducto());
            precio.setText(item.getPrecio());
            unidades.setText(item.getUnidades());
        }
    }
}

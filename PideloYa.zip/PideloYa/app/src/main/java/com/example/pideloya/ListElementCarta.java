package com.example.pideloya;

import java.io.Serializable;

public class ListElementCarta implements Serializable {
    private String producto;
    private String precio;
    private String unidades;


    public ListElementCarta(String producto, String precio, String unidades) {
        this.producto = producto;
        this.precio = precio;
        this.unidades = unidades;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getUnidades() {
        return unidades;
    }

    public void setUnidades(String unidades) {
        this.unidades = unidades;
    }
}

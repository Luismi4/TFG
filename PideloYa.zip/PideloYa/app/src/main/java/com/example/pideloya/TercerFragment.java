package com.example.pideloya;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TercerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TercerFragment extends Fragment {

    Button btnEliminarDatos;
    Button btnModificarDatos;
    private usuarioID usuario;
    private AppConfig appConfig;

    // Parámetros
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public TercerFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TercerFragment.
     */
    // Método de fábrica para crear una nueva instancia del fragmento
    public static TercerFragment newInstance(String param1, String param2) {
        TercerFragment fragment = new TercerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tercer, container, false);

        appConfig = new AppConfig();

        // Obtener el objeto usuarioID desde el Intent
        usuario = (usuarioID) getActivity().getIntent().getSerializableExtra("usuario");

        // Obtener la ID del usuario desde el objeto usuarioID
        final int idUsuario = usuario.getId();

        // Inicializa los elementos
        btnEliminarDatos = view.findViewById(R.id.btnEliminarDatos);
        btnModificarDatos = view.findViewById(R.id.btnModificarDatos);

        // Listener para el botón "Eliminar Datos"
        btnEliminarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminarUsuario(idUsuario);
            }
        });

        // Listener para el botón "Modificar Datos"
        btnModificarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir la actividad ModificarUsuarioActivity
                Intent intent = new Intent(getActivity(), ModificarUsuarioActivity.class);
                intent.putExtra("usuarioID", usuario); // Pasar el objeto usuarioID al intent
                startActivity(intent);
            }
        });

        return view;
    }

    private void eliminarUsuario(final int idUsuario) {
        String url = appConfig.getBaseUrl() + "eliminarusuario.php"; // URL del endpoint PHP

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        JSONObject postData = new JSONObject();
        try {
            postData.put("idUsuario", idUsuario);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (response.has("success")) {
                                Toast.makeText(getActivity(), response.getString("success"), Toast.LENGTH_SHORT).show();
                                // Regresar a la pantalla de login
                                Intent intent = new Intent(getActivity(), MainActivity.class);
                                startActivity(intent);
                                getActivity().finish();
                            } else if (response.has("error")) {
                                Toast.makeText(getActivity(), response.getString("error"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error " + error, Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(request);
    }
}

package com.example.pideloya;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MTraerBarCartaS extends android.app.Activity {
    private static final String TAG = "MTraerBarCartaS";
    private Context mContext;
    private DBHelper dbHelper;
    private AppConfig appConfig;
    private RequestQueue requestQueue;

    public MTraerBarCartaS(Context context) {
        mContext = context;
        dbHelper = new DBHelper(context);
        appConfig = new AppConfig();
        requestQueue = Volley.newRequestQueue(context);
    }

    public void traerDatosDesdeServidor(String nombre) {
        String baseUrl = appConfig.getBaseUrl();
        if (baseUrl == null) {
            Toast.makeText(mContext, "URL base no configurada", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = baseUrl + "/traer_bar_json.php?nombre=" + nombre;
        Log.d(TAG, "URL solicitada: " + url);

        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "Respuesta del servidor: " + response);
                        procesarRespuesta(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        manejarError(error);
                    }
                });

        requestQueue.add(request);
    }

    private void procesarRespuesta(String response) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.has("bares")) {
                JSONArray jsonArray = jsonObject.getJSONArray("bares");
                Log.d(TAG, "Cantidad de bares recibidos: " + jsonArray.length());

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject barObject = jsonArray.getJSONObject(i);
                    Log.d(TAG, "Procesando bar: " + barObject.getString("Nombre_bar"));

                    String idBar = barObject.getString("Id_bar");
                    String nombreBar = barObject.getString("Nombre_bar");
                    String webBar = barObject.getString("Web_bar");
                    String direccionBar = barObject.getString("Direccion_bar");
                    String provincia = barObject.getString("Provincia");

                    if (barObject.has("mcartas")) {
                        JSONArray mCartasArray = barObject.getJSONArray("mcartas");
                        Log.d(TAG, "Cantidad de cartas: " + mCartasArray.length());

                        if (mCartasArray.length() > 0) {
                            for (int j = 0; j < mCartasArray.length(); j++) {
                                JSONObject mCartaObject = mCartasArray.getJSONObject(j);
                                String idC = mCartaObject.getString("MC_idC");

                                if (registroYaExiste(idBar, idC)) {
                                    eliminarDatosAnteriores(idBar, idC);
                                }
                                insertarEnScartas(idC, idBar, mCartaObject.getString("MC_plato1"), mCartaObject.getString("MC_plato2"),
                                        mCartaObject.optString("MC_bebida1", ""), mCartaObject.optString("MC_bebida2", ""),
                                        mCartaObject.optInt("MC_preciop1", 0), mCartaObject.optInt("MC_preciop2", 0),
                                        mCartaObject.optInt("MC_preciob1", 0), mCartaObject.optInt("MC_preciob2", 0),
                                        mCartaObject.optString("MCalergias", ""), mCartaObject.optString("MCobservaciones", ""));
                            }

                            // Lógica para insertar en Slocales solo si hay cartas asociadas
                            insertarEnSlocales(idBar, nombreBar, webBar, direccionBar, provincia);
                        } else {
                            Log.d(TAG, "El bar " + nombreBar + " no tiene cartas.");
                            mostrarToast("El bar " + nombreBar + " no tiene cartas.");
                        }
                    } else {
                        Log.d(TAG, "El bar " + nombreBar + " no tiene cartas.");
                        mostrarToast("El bar " + nombreBar + " no tiene cartas.");
                    }
                }
            } else {
                mostrarToast("No se encontraron datos de bares en la respuesta");
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error al procesar el JSON: " + e.getMessage());
            mostrarToast("Error al procesar la respuesta del servidor");
        } finally {
            db.close();
        }
    }

    private void manejarError(VolleyError error) {
        Log.e(TAG, "Error al obtener los datos del servidor: " + error.getMessage());
        if (error instanceof com.android.volley.NoConnectionError || error instanceof com.android.volley.NetworkError) {
            mostrarToast("Error de conexión");
        } else if (error instanceof com.android.volley.TimeoutError) {
            mostrarToast("Tiempo de espera agotado");
        } else if (error instanceof com.android.volley.ServerError) {
            mostrarToast("Error en el servidor");
        } else {
            mostrarToast("Error desconocido");
        }
    }

    private void mostrarToast(final String mensaje) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, mensaje, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean registroYaExiste(String idBar, String idC) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT * FROM Scartas WHERE SC_IdB = ? AND SC_IdC = ?";
        Cursor cursor = db.rawQuery(query, new String[]{idBar, idC});
        boolean existe = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return existe;
    }

    private void eliminarDatosAnteriores(String idBar, String idC) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("Scartas", "SC_IdB = ? AND SC_IdC = ?", new String[]{idBar, idC});
        db.close();
    }

    private void insertarEnScartas(String idC, String idB, String plato1, String plato2, String bebida1, String bebida2, int preciop1, int preciop2, int preciob1, int preciob2, String alergias, String observaciones) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("SC_IdC", idC);
        values.put("SC_IdB", idB);
        values.put("SC_plato1", plato1);
        values.put("SC_plato2", plato2);
        values.put("SC_bebida1", bebida1);
        values.put("SC_bebida2", bebida2);
        values.put("SC_preciop1", preciop1);
        values.put("SC_preciop2", preciop2);
        values.put("SC_preciob1", preciob1);
        values.put("SC_preciob2", preciob2);
        values.put("SC_alergias", alergias);
        values.put("SC_observaciones", observaciones);
        long resultado = db.insert("Scartas", null, values);
        db.close();
        mostrarToast(resultado != -1 ? "Datos insertados en Scartas" : "Error al insertar datos en Scartas");
    }

    private void insertarEnSlocales(String idBar, String nombreBar, String webBar, String direccionBar, String provincia) {
        if (registroYaExisteLocal(idBar)) {
            actualizarEnSlocales(idBar, nombreBar, webBar, direccionBar, provincia);
        } else {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("id", idBar);
            values.put("nombre", nombreBar);
            values.put("direccion", direccionBar);
            values.put("web", webBar);
            values.put("provincia", provincia);
            long resultado = db.insert("Slocales", null, values);
            db.close();
            mostrarToast(resultado != -1 ? "Datos insertados en Slocales" : "Error al insertar datos en Slocales");
        }
    }

    private boolean registroYaExisteLocal(String idBar) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT * FROM Slocales WHERE id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{idBar});
        boolean existe = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return existe;
    }

    private void actualizarEnSlocales(String idBar, String nombreBar, String webBar, String direccionBar, String provincia) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre", nombreBar);
        values.put("direccion", direccionBar);
        values.put("web", webBar);
        values.put("provincia", provincia);
        int resultado = db.update("Slocales", values, "id = ?", new String[]{idBar});
        db.close();
        mostrarToast(resultado != 0 ? "Datos actualizados en Slocales" : "Error al actualizar datos en Slocales");
    }
}
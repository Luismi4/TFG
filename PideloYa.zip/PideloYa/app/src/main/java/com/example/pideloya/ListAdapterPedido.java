package com.example.pideloya;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListAdapterPedido extends RecyclerView.Adapter<ListAdapterPedido.ViewHolder> {

    private List<ListElementPedido> mElements;
    private Context mContext;

    public ListAdapterPedido(List<ListElementPedido> elements, Context context) {
        mElements = elements;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_pedidos, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ListElementPedido element = mElements.get(position);

        // Asignar los valores de los platos a los TextView correspondientes
        holder.textViewPlato1.setText(element.getPlato1());
        holder.textViewPrecioPlato1.setText(element.getPrecioPlato1());
        holder.textViewCantidadPlato1.setText(String.valueOf(element.getCantidadPlato1()));
        holder.textViewPrecioTotalPlato1.setText(element.getPrecioTotalPlato1());

        holder.textViewPlato2.setText(element.getPlato2());
        holder.textViewPrecioPlato2.setText(element.getPrecioPlato2());
        holder.textViewCantidadPlato2.setText(String.valueOf(element.getCantidadPlato2()));
        holder.textViewPrecioTotalPlato2.setText(element.getPrecioTotalPlato2());

        // Asignar los valores de las bebidas a los TextView correspondientes
        holder.textViewBebida1.setText(element.getBebida1());
        holder.textViewPrecioBebida1.setText(element.getPrecioBebida1());
        holder.textViewCantidadBebida1.setText(String.valueOf(element.getCantidadBebida1()));
        holder.textViewPrecioTotalBebida1.setText(element.getPrecioTotalBebida1());

        holder.textViewBebida2.setText(element.getBebida2());
        holder.textViewPrecioBebida2.setText(element.getPrecioBebida2());
        holder.textViewCantidadBebida2.setText(String.valueOf(element.getCantidadBebida2()));
        holder.textViewPrecioTotalBebida2.setText(element.getPrecioTotalBebida2());

        holder.textViewFechaPedido.setText(element.getFechaPedido());
        holder.textViewPrecioTotal.setText(element.getPrecioTotal());

        // Asegurarse de que las vistas de los platos y bebidas sean visibles
        holder.textViewPlato1.setVisibility(View.VISIBLE);
        holder.textViewPrecioPlato1.setVisibility(View.VISIBLE);
        holder.textViewCantidadPlato1.setVisibility(View.VISIBLE);
        holder.textViewPrecioTotalPlato1.setVisibility(View.VISIBLE);

        holder.textViewPlato2.setVisibility(View.VISIBLE);
        holder.textViewPrecioPlato2.setVisibility(View.VISIBLE);
        holder.textViewCantidadPlato2.setVisibility(View.VISIBLE);
        holder.textViewPrecioTotalPlato2.setVisibility(View.VISIBLE);

        holder.textViewBebida1.setVisibility(View.VISIBLE);
        holder.textViewPrecioBebida1.setVisibility(View.VISIBLE);
        holder.textViewCantidadBebida1.setVisibility(View.VISIBLE);
        holder.textViewPrecioTotalBebida1.setVisibility(View.VISIBLE);

        holder.textViewBebida2.setVisibility(View.VISIBLE);
        holder.textViewPrecioBebida2.setVisibility(View.VISIBLE);
        holder.textViewCantidadBebida2.setVisibility(View.VISIBLE);
        holder.textViewPrecioTotalBebida2.setVisibility(View.VISIBLE);

        holder.textViewFechaPedido.setVisibility(View.VISIBLE);
        holder.textViewPrecioTotal.setVisibility(View.VISIBLE);
    }


    @Override
    public int getItemCount() {
        return mElements.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewPlato1;
        TextView textViewPrecioPlato1;
        TextView textViewCantidadPlato1;
        TextView textViewPrecioTotalPlato1;

        TextView textViewPlato2;
        TextView textViewPrecioPlato2;
        TextView textViewCantidadPlato2;
        TextView textViewPrecioTotalPlato2;

        TextView textViewBebida1;
        TextView textViewPrecioBebida1;
        TextView textViewCantidadBebida1;
        TextView textViewPrecioTotalBebida1;

        TextView textViewBebida2;
        TextView textViewPrecioBebida2;
        TextView textViewCantidadBebida2;
        TextView textViewPrecioTotalBebida2;

        TextView textViewFechaPedido;
        TextView textViewPrecioTotal;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewPlato1 = itemView.findViewById(R.id.textViewPlato1);
            textViewPrecioPlato1 = itemView.findViewById(R.id.textViewPrecioPlato1);
            textViewCantidadPlato1 = itemView.findViewById(R.id.textViewCantidadPlato1);
            textViewPrecioTotalPlato1 = itemView.findViewById(R.id.textViewPrecioTotalPlato1);

            textViewPlato2 = itemView.findViewById(R.id.textViewPlato2);
            textViewPrecioPlato2 = itemView.findViewById(R.id.textViewPrecioPlato2);
            textViewCantidadPlato2 = itemView.findViewById(R.id.textViewCantidadPlato2);
            textViewPrecioTotalPlato2 = itemView.findViewById(R.id.textViewPrecioTotalPlato2);

            textViewBebida1 = itemView.findViewById(R.id.textViewBebida1);
            textViewPrecioBebida1 = itemView.findViewById(R.id.textViewPrecioBebida1);
            textViewCantidadBebida1 = itemView.findViewById(R.id.textViewCantidadBebida1);
            textViewPrecioTotalBebida1 = itemView.findViewById(R.id.textViewPrecioTotalBebida1);

            textViewBebida2 = itemView.findViewById(R.id.textViewBebida2);
            textViewPrecioBebida2 = itemView.findViewById(R.id.textViewPrecioBebida2);
            textViewCantidadBebida2 = itemView.findViewById(R.id.textViewCantidadBebida2);
            textViewPrecioTotalBebida2 = itemView.findViewById(R.id.textViewPrecioTotalBebida2);

            textViewFechaPedido = itemView.findViewById(R.id.textViewFechaPedido);
            textViewPrecioTotal = itemView.findViewById(R.id.textViewPrecioTotal);
        }
    }
}

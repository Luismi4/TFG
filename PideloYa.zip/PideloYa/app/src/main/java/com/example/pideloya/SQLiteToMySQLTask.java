package com.example.pideloya;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SQLiteToMySQLTask extends AsyncTask<Void, Void, Boolean> {

    private Context mContext;

    public SQLiteToMySQLTask(Context context) {
        mContext = context;
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        Connection sqliteConnection = null;
        try {
            // Conexión a la base de datos SQLite
            Class.forName("org.sqlite.JDBC");
            sqliteConnection = DriverManager.getConnection("jdbc:sqlite:locales.db");

            // Consulta para obtener el último registro de la tabla SQLite Pedidos
            String query = "SELECT id_pedido, id_mesa, fecha_pedido, plato_1, cantidad_plato_1, plato_2, cantidad_plato_2, bebida_1, cantidad_bebida_1, bebida_2, cantidad_bebida_2 FROM Pedidos ORDER BY id_pedido DESC LIMIT 1";
            Statement statement = sqliteConnection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Crear objeto JSON para almacenar los datos
            JSONObject json = new JSONObject();
            if (resultSet.next()) {
                json.put("id_mesa", resultSet.getInt("id_mesa"));
                json.put("fecha_pedido", resultSet.getString("fecha_pedido"));
                json.put("plato_1", resultSet.getString("plato_1"));
                json.put("cantidad_plato_1", resultSet.getInt("cantidad_plato_1"));
                json.put("plato_2", resultSet.getString("plato_2"));
                json.put("cantidad_plato_2", resultSet.getInt("cantidad_plato_2"));
                json.put("bebida_1", resultSet.getString("bebida_1"));
                json.put("cantidad_bebida_1", resultSet.getInt("cantidad_bebida_1"));
                json.put("bebida_2", resultSet.getString("bebida_2"));
                json.put("cantidad_bebida_2", resultSet.getInt("cantidad_bebida_2"));

                // Enviar los datos al servidor PHP y retornar true si se envían correctamente
                return sendToPHP(json);
            } else {
                Log.e("SQLiteToMySQLTask", "No se encontraron registros en la tabla Pedidos.");
                return false;
            }

        } catch (Exception e) {
            Log.e("SQLiteToMySQLTask", "Error al obtener datos de SQLite: " + e.getMessage());
            return false;
        } finally {
            try {
                if (sqliteConnection != null) {
                    sqliteConnection.close();
                }
            } catch (Exception e) {
                Log.e("SQLiteToMySQLTask", "Error al cerrar conexión SQLite: " + e.getMessage());
            }
        }
    }

    private Boolean sendToPHP(JSONObject json) {
        try {
            String url = AppConfig.getBaseUrl() + "guardar_pedido.php"; // Reemplaza "guardar_pedido.php" con el nombre de tu script PHP

            RequestQueue requestQueue = Volley.newRequestQueue(mContext);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, json,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Manejar la respuesta del servidor si es necesario
                            Log.i("SQLiteToMySQLTask", "Datos enviados al servidor PHP correctamente.");
                            showToast("Datos enviados al servidor PHP correctamente.");
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // Manejar errores de la solicitud
                            Log.e("SQLiteToMySQLTask", "Error al enviar datos al servidor PHP: " + error.getMessage());
                            showToast("Error al enviar datos al servidor PHP. Por favor, inténtelo de nuevo.");
                        }
                    });

            requestQueue.add(jsonObjectRequest);

            return true;

        } catch (Exception e) {
            Log.e("SQLiteToMySQLTask", "Error al enviar datos al servidor PHP: " + e.getMessage());
            return false;
        }
    }

    @Override
    protected void onPostExecute(Boolean result) {
        // No se necesitan acciones específicas aquí, ya que la respuesta se maneja dentro de sendToPHP()
    }

    private void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }
}

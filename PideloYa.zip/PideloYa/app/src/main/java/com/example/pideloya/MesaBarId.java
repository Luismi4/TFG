package com.example.pideloya;
import java.io.Serializable;

public class MesaBarId implements Serializable {
    private String idMesa;
    private String idBar;

    public MesaBarId(String idMesa, String idBar) {
        this.idMesa = idMesa;
        this.idBar = idBar;
    }

    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }

    public String getIdBar() {
        return idBar;
    }

    public void setIdBar(String idBar) {
        this.idBar = idBar;
    }


}

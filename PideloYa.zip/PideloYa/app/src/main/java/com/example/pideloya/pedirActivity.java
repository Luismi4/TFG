package com.example.pideloya;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

// Agrega esta línea para importar la clase SQLiteToMySQLTask
import com.example.pideloya.SQLiteToMySQLTask;

public class pedirActivity extends AppCompatActivity {

    private ListAdapterCarta mAdapter;
    private List<ListElementCarta> mCartas;
    private RecyclerView recyclerView;
    private DBHelper dbHelper;
    private MesaBarId mesaBarId;
    private ContentValues values;
    private PedidoManager pedidoManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
                {
                    super.onCreate(savedInstanceState);
                    setContentView(R.layout.activity_pedir);

                    recyclerView = findViewById(R.id.recyclerView);
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    pedidoManager = new PedidoManager(this);

                    dbHelper = new DBHelper(this);

                    mesaBarId = (MesaBarId) getIntent().getSerializableExtra("MesaBarId");

                    mCartas = dbHelper.getCartas();
                    mAdapter = new ListAdapterCarta(mCartas, this, recyclerView);
                    recyclerView.setAdapter(mAdapter);

                    Button btnHacerPedido = findViewById(R.id.buttonPlaceOrder);
                    btnHacerPedido.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            double precioTotalPedido = calcularPrecioTotalPedido();
                            guardarPedido(precioTotalPedido);

                            String baseUrl = AppConfig.getBaseUrl();


                            // Llamar a enviarPedidoDesdeSQLite cuando se presione el botón
                            pedidoManager.enviarPedidoDesdeSQLite(baseUrl + "guardar_pedido.php");
                        }
                    });
                }

    private double calcularPrecioTotalPedido() {
        double precioTotalPedido = 0.0;
        for (int i = 0; i < mCartas.size(); i++) {
            ListElementCarta item = mCartas.get(i);
            double precioUnitario = Double.parseDouble(item.getPrecio());
            EditText editTextQuantity = mAdapter.getEditTextQuantity(i);
            if (editTextQuantity != null) {
                String quantityText = editTextQuantity.getText().toString();
                int cantidad = quantityText.isEmpty() ? 0 : Integer.parseInt(quantityText);
                precioTotalPedido += precioUnitario * cantidad;
            }
        }
        return precioTotalPedido;
    }

    private void guardarPedido(double precioTotal) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(DBHelper.COLUMN_ID_MESA, mesaBarId.getIdMesa());
        values.put(DBHelper.COLUMN_ID_BAR, mesaBarId.getIdBar());
        values.put(DBHelper.COLUMN_FECHA_PEDIDO, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        for (int i = 0; i < mCartas.size() && i < 4; i++) {
            ListElementCarta item = mCartas.get(i);
            String producto = item.getProducto();
            double precioUnitario = Double.parseDouble(item.getPrecio());
            EditText editTextQuantity = mAdapter.getEditTextQuantity(i);
            int cantidad = editTextQuantity != null && !editTextQuantity.getText().toString().isEmpty() ? Integer.parseInt(editTextQuantity.getText().toString()) : 0;
            double precioTotalItem = precioUnitario * cantidad;

            if (i == 0) {
                values.put(DBHelper.COLUMN_PLATO_1, producto);
                values.put(DBHelper.COLUMN_PRECIO_PLATO_1, precioUnitario);
                values.put(DBHelper.COLUMN_CANTIDAD_PLATO_1, cantidad);
                values.put(DBHelper.COLUMN_PRECIO_TOTAL_PLATO_1, precioTotalItem);
            } else if (i == 1) {
                values.put(DBHelper.COLUMN_PLATO_2, producto);
                values.put(DBHelper.COLUMN_PRECIO_PLATO_2, precioUnitario);
                values.put(DBHelper.COLUMN_CANTIDAD_PLATO_2, cantidad);
                values.put(DBHelper.COLUMN_PRECIO_TOTAL_PLATO_2, precioTotalItem);
            } else if (i == 2) {
                values.put(DBHelper.COLUMN_BEBIDA_1, producto);
                values.put(DBHelper.COLUMN_PRECIO_BEBIDA_1, precioUnitario);
                values.put(DBHelper.COLUMN_CANTIDAD_BEBIDA_1, cantidad);
                values.put(DBHelper.COLUMN_PRECIO_TOTAL_BEBIDA_1, precioTotalItem);
            } else if (i == 3) {
                values.put(DBHelper.COLUMN_BEBIDA_2, producto);
                values.put(DBHelper.COLUMN_PRECIO_BEBIDA_2, precioUnitario);
                values.put(DBHelper.COLUMN_CANTIDAD_BEBIDA_2, cantidad);
                values.put(DBHelper.COLUMN_PRECIO_TOTAL_BEBIDA_2, precioTotalItem);
            }
        }

        values.put(DBHelper.COLUMN_PRECIO_TOTAL, precioTotal);

        long newRowId = db.insert(DBHelper.TABLE_PEDIDOS, null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Pedido guardado con éxito", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(pedirActivity.this, logeado.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Error al guardar el pedido", Toast.LENGTH_SHORT).show();
        }
    }

}

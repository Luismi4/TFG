package com.example.pideloya;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    EditText usernameEditText;   // EditText para el Nombre del Usuario
    EditText passwordEditText;   // EditText para la Contraseña
    Button loginButton;          // Botón para Logarse
    Button registerButton;       // Botón para Registrarse

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa los elementos
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Listener para el botón "Logarse"
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obtener los textos añadidos por el usuario
                String usuario = usernameEditText.getText().toString();
                String contrasena = passwordEditText.getText().toString();

                // Verifica si la URL base ya está almacenada, sino obténla (por seguridad)
                if (AppConfig.getBaseUrl() != null) {
                    realizarSolicitudHttp(usuario, contrasena);
                } else {
                    Toast.makeText(getApplicationContext(), "No se pudo obtener la URL base. Intente nuevamente.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Listener para el botón "Registrarse"
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Abre la actividad para registrar un nuevo usuario
                Intent intent = new Intent(MainActivity.this, registrarse.class);
                startActivity(intent);

                // Cierra esta actividad
                finish();
            }
        });
    }

    private void realizarSolicitudHttp(final String usuario, final String contrasena) {
        RequestQueue queue = Volley.newRequestQueue(this);
        JSONObject postData = new JSONObject();
        try {
            postData.put("Usuario", usuario);
            postData.put("Contrasena", contrasena);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String loginUrl = AppConfig.getBaseUrl() + "consultar_login.php"; // Utiliza la URL base obtenida
        System.out.println("Valor de loginUrl: " + loginUrl);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, loginUrl, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        procesarJSON(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error de conexión. Verifica tu conexión a Internet.", Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(request);
    }

    private void procesarJSON(JSONObject jsonObject) {
        try {
            if (jsonObject.has("idUsuario") && !jsonObject.isNull("idUsuario")) {
                String idUsuario = jsonObject.getString("idUsuario");
                int id = Integer.parseInt(idUsuario);
                String mensaje = "Usuario encontrado";
                Toast.makeText(getApplicationContext(), mensaje, Toast.LENGTH_SHORT).show();

                // Crear una instancia de usuarioID y guardar la ID
                usuarioID usuario = new usuarioID(id);

                // Redirigir a UsuarioLogeadoActivity
                Intent intent = new Intent(MainActivity.this, logeado.class);
                intent.putExtra("usuario", usuario); // Pasar el objeto usuarioID a la otra actividad
                startActivity(intent);
                finish();
            } else {
                String mensaje = "No se encuentra el usuario, inténtelo de nuevo";
                Toast.makeText(getApplicationContext(), mensaje, Toast.LENGTH_SHORT).show();

                usernameEditText.setText("");
                passwordEditText.setText("");

                usernameEditText.requestFocus();
            }
        } catch (JSONException e) {
            Log.e("TAG", "Error al procesar el JSON: " + e.getMessage());
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Error en el formato JSON", Toast.LENGTH_SHORT).show();
        }
    }
}


package com.example.pideloya;

import java.io.Serializable;

public class ListElementPedido implements Serializable {
    private String plato1;
    private String precioPlato1;
    private int cantidadPlato1;
    private String precioTotalPlato1;
    private String plato2;
    private String precioPlato2;
    private int cantidadPlato2;
    private String precioTotalPlato2;
    private String bebida1;
    private String precioBebida1;
    private int cantidadBebida1;
    private String precioTotalBebida1;
    private String bebida2;
    private String precioBebida2;
    private int cantidadBebida2;
    private String precioTotalBebida2;
    private String fechaPedido;
    private String precioTotal;

    // Constructor
    public ListElementPedido(String plato1, String precioPlato1, int cantidadPlato1, String precioTotalPlato1,
                             String plato2, String precioPlato2, int cantidadPlato2, String precioTotalPlato2,
                             String bebida1, String precioBebida1, int cantidadBebida1, String precioTotalBebida1,
                             String bebida2, String precioBebida2, int cantidadBebida2, String precioTotalBebida2,
                             String fechaPedido, String precioTotal) {
        this.plato1 = plato1;
        this.precioPlato1 = precioPlato1;
        this.cantidadPlato1 = cantidadPlato1;
        this.precioTotalPlato1 = precioTotalPlato1;
        this.plato2 = plato2;
        this.precioPlato2 = precioPlato2;
        this.cantidadPlato2 = cantidadPlato2;
        this.precioTotalPlato2 = precioTotalPlato2;
        this.bebida1 = bebida1;
        this.precioBebida1 = precioBebida1;
        this.cantidadBebida1 = cantidadBebida1;
        this.precioTotalBebida1 = precioTotalBebida1;
        this.bebida2 = bebida2;
        this.precioBebida2 = precioBebida2;
        this.cantidadBebida2 = cantidadBebida2;
        this.precioTotalBebida2 = precioTotalBebida2;
        this.fechaPedido = fechaPedido;
        this.precioTotal = precioTotal;
    }

    // Getters
    public String getPlato1() {
        return plato1;
    }

    public String getPrecioPlato1() {
        return precioPlato1;
    }

    public int getCantidadPlato1() {
        return cantidadPlato1;
    }

    public String getPrecioTotalPlato1() {
        return precioTotalPlato1;
    }

    public String getPlato2() {
        return plato2;
    }

    public String getPrecioPlato2() {
        return precioPlato2;
    }

    public int getCantidadPlato2() {
        return cantidadPlato2;
    }

    public String getPrecioTotalPlato2() {
        return precioTotalPlato2;
    }

    public String getBebida1() {
        return bebida1;
    }

    public String getPrecioBebida1() {
        return precioBebida1;
    }

    public int getCantidadBebida1() {
        return cantidadBebida1;
    }

    public String getPrecioTotalBebida1() {
        return precioTotalBebida1;
    }

    public String getBebida2() {
        return bebida2;
    }

    public String getPrecioBebida2() {
        return precioBebida2;
    }

    public int getCantidadBebida2() {
        return cantidadBebida2;
    }

    public String getPrecioTotalBebida2() {
        return precioTotalBebida2;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public String getPrecioTotal() {
        return precioTotal;
    }
}

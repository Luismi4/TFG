package com.example.pideloya;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    // Nombre de la base de datos
    public static final String DATABASE_NAME = "locales.db";
    // Versión de la base de datos
    private static final int DATABASE_VERSION = 1;

    // Nombre de la tabla y nombres de las columnas
    public static final String TABLE_LOCALES = "Slocales";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_DIRECCION = "direccion";
    public static final String COLUMN_WEB = "web";
    public static final String COLUMN_PROVINCIA = "provincia";

    // Sentencia SQL para crear la tabla de Locales
    public static final String SQL_CREATE_TABLE_LOCALES =
            "CREATE TABLE " + TABLE_LOCALES + " (" +
                    COLUMN_ID + " INTEGER," +
                    COLUMN_NOMBRE + " TEXT," +
                    COLUMN_DIRECCION + " TEXT," +
                    COLUMN_WEB + " TEXT," +
                    COLUMN_PROVINCIA + " TEXT)";

    // Sentencia SQL para eliminar la tabla de Locales
    public static final String SQL_DROP_TABLE_LOCALES =
            "DROP TABLE IF EXISTS " + TABLE_LOCALES;




    // Nombre de la segunda tabla y nombres de las columnas
    public static final String TABLE_SCARTAS = "Scartas";
    public static final String COLUMN_IDC = "SC_IdC";
    public static final String COLUMN_IDB = "SC_IdB";
    public static final String COLUMN_SC_plato1 = "SC_plato1";
    public static final String COLUMN_SC_plato2 = "SC_plato2";
    public static final String COLUMN_SC_bebida1 = "SC_bebida1";
    public static final String COLUMN_SC_bebida2 = "SC_bebida2";
    public static final String COLUMN_SC_preciop1 = "SC_preciop1";
    public static final String COLUMN_SC_preciop2 = "SC_preciop2";
    public static final String COLUMN_SC_preciob1 = "SC_preciob1";
    public static final String COLUMN_SC_preciob2 = "SC_preciob2";
    public static final String COLUMN_SC_alergias = "SC_alergias";
    public static final String COLUMN_SC_observaciones = "SC_observaciones";

    // Sentencia SQL para crear la tabla de Scartas
    public static final String SQL_CREATE_TABLE_SCARTAS =
            "CREATE TABLE " + TABLE_SCARTAS + " (" +
                    COLUMN_ID + " INTEGER," +
                    COLUMN_IDC + " INTEGER," +
                    COLUMN_IDB + " INTEGER," +
                    COLUMN_SC_plato1 + " TEXT," +
                    COLUMN_SC_plato2 + " TEXT," +
                    COLUMN_SC_bebida1 + " TEXT," +
                    COLUMN_SC_bebida2 + " TEXT," +
                    COLUMN_SC_preciop1 + " TEXT," +
                    COLUMN_SC_preciop2 + " TEXT," +
                    COLUMN_SC_preciob1 + " TEXT," +
                    COLUMN_SC_preciob2 + " TEXT," +
                    COLUMN_SC_alergias + " TEXT," +
                    COLUMN_SC_observaciones + " TEXT)";

    // Sentencia SQL para eliminar la tabla de Scartas
    public static final String SQL_DROP_TABLE_SCARTAS =
            "DROP TABLE IF EXISTS " + TABLE_SCARTAS;

    // Nombre de la tercera tabla (Pedidos) y nombres de las columnas
    public static final String TABLE_PEDIDOS = "pedidos";
    public static final String COLUMN_ID_PEDIDO = "id_pedido";
    public static final String COLUMN_ID_MESA = "id_mesa";
    public static final String COLUMN_ID_BAR = "id_bar";
    public static final String COLUMN_FECHA_PEDIDO = "fecha_pedido";
    public static final String COLUMN_PLATO_1 = "plato_1";
    public static final String COLUMN_PRECIO_PLATO_1 = "precio_plato_1";
    public static final String COLUMN_CANTIDAD_PLATO_1 = "cantidad_plato_1";
    public static final String COLUMN_PRECIO_TOTAL_PLATO_1 = "precio_total_plato_1";
    public static final String COLUMN_PLATO_2 = "plato_2";
    public static final String COLUMN_PRECIO_PLATO_2 = "precio_plato_2";
    public static final String COLUMN_CANTIDAD_PLATO_2 = "cantidad_plato_2";
    public static final String COLUMN_PRECIO_TOTAL_PLATO_2 = "precio_total_plato_2";
    public static final String COLUMN_BEBIDA_1 = "bebida_1";
    public static final String COLUMN_PRECIO_BEBIDA_1 = "precio_bebida_1";
    public static final String COLUMN_CANTIDAD_BEBIDA_1 = "cantidad_bebida_1";
    public static final String COLUMN_PRECIO_TOTAL_BEBIDA_1 = "precio_total_bebida_1";
    public static final String COLUMN_BEBIDA_2 = "bebida_2";
    public static final String COLUMN_PRECIO_BEBIDA_2 = "precio_bebida_2";
    public static final String COLUMN_CANTIDAD_BEBIDA_2 = "cantidad_bebida_2";
    public static final String COLUMN_PRECIO_TOTAL_BEBIDA_2 = "precio_total_bebida_2";
    public static final String COLUMN_PRECIO_TOTAL = "precio_total";

    // Sentencia SQL para crear la tabla de Pedidos
    public static final String SQL_CREATE_TABLE_PEDIDOS =
            "CREATE TABLE " + TABLE_PEDIDOS + " (" +
                    COLUMN_ID_PEDIDO + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_ID_MESA + " INTEGER," +
                    COLUMN_ID_BAR + " INTEGER," +
                    COLUMN_FECHA_PEDIDO + " TEXT," +
                    COLUMN_PLATO_1 + " TEXT," +
                    COLUMN_PRECIO_PLATO_1 + " TEXT," +
                    COLUMN_CANTIDAD_PLATO_1 + " INTEGER," +
                    COLUMN_PRECIO_TOTAL_PLATO_1 + " TEXT," +
                    COLUMN_PLATO_2 + " TEXT," +
                    COLUMN_PRECIO_PLATO_2 + " TEXT," +
                    COLUMN_CANTIDAD_PLATO_2 + " INTEGER," +
                    COLUMN_PRECIO_TOTAL_PLATO_2 + " TEXT," +
                    COLUMN_BEBIDA_1 + " TEXT," +
                    COLUMN_PRECIO_BEBIDA_1 + " TEXT," +
                    COLUMN_CANTIDAD_BEBIDA_1 + " INTEGER," +
                    COLUMN_PRECIO_TOTAL_BEBIDA_1 + " TEXT," +
                    COLUMN_BEBIDA_2 + " TEXT," +
                    COLUMN_PRECIO_BEBIDA_2 + " TEXT," +
                    COLUMN_CANTIDAD_BEBIDA_2 + " INTEGER," +
                    COLUMN_PRECIO_TOTAL_BEBIDA_2 + " TEXT," +
                    COLUMN_PRECIO_TOTAL + " TEXT)";

    // Sentencia SQL para eliminar la tabla de Pedidos
    public static final String SQL_DROP_TABLE_PEDIDOS =
            "DROP TABLE IF EXISTS " + TABLE_PEDIDOS;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear la tabla de Locales
        db.execSQL(SQL_CREATE_TABLE_LOCALES);

        // Crear la tabla de Scartas
        db.execSQL(SQL_CREATE_TABLE_SCARTAS);

        // Crear la tabla de Pedidos
        db.execSQL(SQL_CREATE_TABLE_PEDIDOS);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Borrar la tabla si existe y crearla de nuevo
        db.execSQL(SQL_DROP_TABLE_LOCALES);
        db.execSQL(SQL_DROP_TABLE_SCARTAS);
        db.execSQL(SQL_DROP_TABLE_PEDIDOS);
        onCreate(db);
    }

    public List<ListElement> getAllBars() {
        List<ListElement> bars = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_LOCALES, null);

            if (cursor.moveToFirst()) {
                do {
                    int nombreIndex = cursor.getColumnIndexOrThrow(COLUMN_NOMBRE);
                    int direccionIndex = cursor.getColumnIndexOrThrow(COLUMN_DIRECCION);
                    int provinciaIndex = cursor.getColumnIndexOrThrow(COLUMN_PROVINCIA);

                    String nombre = cursor.getString(nombreIndex);
                    String direccion = cursor.getString(direccionIndex);
                    String provincia = cursor.getString(provinciaIndex);

                    // Assuming a random color for the example, you might want to store colors in the DB as well
                    String color = "#775447";
                    bars.add(new ListElement(color, nombre, provincia));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return bars;
    }

    public List<ListElementCarta> getCartas() {
        List<ListElementCarta> cartas = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SCARTAS, new String[]{
                COLUMN_SC_plato1, COLUMN_SC_preciop1,
                COLUMN_SC_plato2, COLUMN_SC_preciop2,
                COLUMN_SC_bebida1, COLUMN_SC_preciob1,
                COLUMN_SC_bebida2, COLUMN_SC_preciob2
        }, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String plato1 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_plato1));
                String preciop1 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_preciop1));
                String plato2 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_plato2));
                String preciop2 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_preciop2));
                String bebida1 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_bebida1));
                String preciob1 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_preciob1));
                String bebida2 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_bebida2));
                String preciob2 = cursor.getString(cursor.getColumnIndex(COLUMN_SC_preciob2));

                if (plato1 != null && !plato1.isEmpty()) {
                    cartas.add(new ListElementCarta(plato1, preciop1, ""));
                }
                if (plato2 != null && !plato2.isEmpty()) {
                    cartas.add(new ListElementCarta(plato2, preciop2, ""));
                }
                if (bebida1 != null && !bebida1.isEmpty()) {
                    cartas.add(new ListElementCarta(bebida1, preciob1, ""));
                }
                if (bebida2 != null && !bebida2.isEmpty()) {
                    cartas.add(new ListElementCarta(bebida2, preciob2, ""));
                }
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return cartas;
    }

    // Método para obtener todos los pedidos
    // Método para obtener todos los pedidos
    public List<ListElementPedido> getAllPedidos() {
        List<ListElementPedido> pedidos = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String[] columns = {COLUMN_FECHA_PEDIDO, COLUMN_PLATO_1, COLUMN_PRECIO_PLATO_1, COLUMN_CANTIDAD_PLATO_1,
                    COLUMN_PRECIO_TOTAL_PLATO_1, COLUMN_PLATO_2, COLUMN_PRECIO_PLATO_2, COLUMN_CANTIDAD_PLATO_2,
                    COLUMN_PRECIO_TOTAL_PLATO_2, COLUMN_BEBIDA_1, COLUMN_PRECIO_BEBIDA_1, COLUMN_CANTIDAD_BEBIDA_1,
                    COLUMN_PRECIO_TOTAL_BEBIDA_1, COLUMN_BEBIDA_2, COLUMN_PRECIO_BEBIDA_2, COLUMN_CANTIDAD_BEBIDA_2,
                    COLUMN_PRECIO_TOTAL_BEBIDA_2, COLUMN_PRECIO_TOTAL};
            cursor = db.query(TABLE_PEDIDOS, columns, null, null, null, null, null);

            if (cursor.moveToFirst()) {
                do {
                    // Obtener los datos de cada columna del cursor
                    String fechaPedido = cursor.getString(cursor.getColumnIndex(COLUMN_FECHA_PEDIDO));
                    String plato1 = cursor.getString(cursor.getColumnIndex(COLUMN_PLATO_1));
                    String precioPlato1 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_PLATO_1));
                    int cantidadPlato1 = cursor.getInt(cursor.getColumnIndex(COLUMN_CANTIDAD_PLATO_1));
                    String precioTotalPlato1 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_TOTAL_PLATO_1));
                    String plato2 = cursor.getString(cursor.getColumnIndex(COLUMN_PLATO_2));
                    String precioPlato2 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_PLATO_2));
                    int cantidadPlato2 = cursor.getInt(cursor.getColumnIndex(COLUMN_CANTIDAD_PLATO_2));
                    String precioTotalPlato2 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_TOTAL_PLATO_2));
                    String bebida1 = cursor.getString(cursor.getColumnIndex(COLUMN_BEBIDA_1));
                    String precioBebida1 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_BEBIDA_1));
                    int cantidadBebida1 = cursor.getInt(cursor.getColumnIndex(COLUMN_CANTIDAD_BEBIDA_1));
                    String precioTotalBebida1 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_TOTAL_BEBIDA_1));
                    String bebida2 = cursor.getString(cursor.getColumnIndex(COLUMN_BEBIDA_2));
                    String precioBebida2 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_BEBIDA_2));
                    int cantidadBebida2 = cursor.getInt(cursor.getColumnIndex(COLUMN_CANTIDAD_BEBIDA_2));
                    String precioTotalBebida2 = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_TOTAL_BEBIDA_2));
                    String precioTotal = cursor.getString(cursor.getColumnIndex(COLUMN_PRECIO_TOTAL));

                    // Crear un objeto ListElementPedido y agregarlo a la lista
                    ListElementPedido pedido = new ListElementPedido(plato1, precioPlato1, cantidadPlato1, precioTotalPlato1,
                            plato2, precioPlato2, cantidadPlato2, precioTotalPlato2, bebida1, precioBebida1, cantidadBebida1, precioTotalBebida1,
                            bebida2, precioBebida2, cantidadBebida2, precioTotalBebida2, fechaPedido, precioTotal);
                    pedidos.add(pedido);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return pedidos;
    }



}


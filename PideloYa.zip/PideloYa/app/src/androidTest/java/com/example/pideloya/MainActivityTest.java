package com.example.pideloya;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4ClassRunner.class)
public class MainActivityTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityRule = new ActivityScenarioRule<>(MainActivity.class);

    @Test
    public void testBotonesYEditTexts() {
        // Verificar que los EditText estén visibles
        Espresso.onView(ViewMatchers.withId(R.id.usernameEditText)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.passwordEditText)).check(matches(isDisplayed()));

        // Verificar que los botones estén visibles
        Espresso.onView(ViewMatchers.withId(R.id.loginButton)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.registerButton)).check(matches(isDisplayed()));

        // Realizar acciones en los EditTexts y botones
        Espresso.onView(withId(R.id.usernameEditText)).perform(ViewActions.typeText("usuario_prueba"));
        Espresso.onView(withId(R.id.passwordEditText)).perform(ViewActions.replaceText("contraseña_prueba"));

        // Hacer clic en el botón "Logarse"
        Espresso.onView(withId(R.id.loginButton)).perform(ViewActions.click());

        // Verificar que el botón "Registrarse" esté visible
        Espresso.onView(ViewMatchers.withId(R.id.registerButton)).check(matches(isDisplayed()));

        // Hacer clic en el botón "Registrarse"
        Espresso.onView(withId(R.id.registerButton)).perform(ViewActions.click());
    }
}

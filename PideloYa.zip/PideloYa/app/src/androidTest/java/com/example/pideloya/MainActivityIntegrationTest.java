package com.example.pideloya;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

@RunWith(AndroidJUnit4ClassRunner.class)
public class MainActivityIntegrationTest {

    @Rule
    public ActivityScenarioRule<registrarse> activityRule = new ActivityScenarioRule<>(registrarse.class);

    @Test
    public void testElementsVisibilityAndActions() {
        // Verificar la visibilidad de los elementos
        Espresso.onView(withId(R.id.editTextNombre)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.editTextUsuario)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.correo)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.editTextDNI)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.editTextContrasena)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.buttonRegistrar)).check(matches(isDisplayed()));

        // Realizar acciones de usuario
        Espresso.onView(withId(R.id.editTextNombre)).perform(ViewActions.typeText("John Doe"));
        Espresso.onView(withId(R.id.editTextUsuario)).perform(ViewActions.typeText("johndoe"));
        Espresso.onView(withId(R.id.correo)).perform(ViewActions.typeText("john@example.com"));
        Espresso.onView(withId(R.id.editTextDNI)).perform(ViewActions.typeText("12345678A"));
        Espresso.onView(withId(R.id.editTextContrasena)).perform(ViewActions.typeText("password"));

        // Hacer clic en el botón de registro
        Espresso.onView(withId(R.id.buttonRegistrar)).perform(ViewActions.click());

        // Verificar acciones realizadas
        // (puedes agregar más verificaciones aquí dependiendo de la lógica de tu actividad)
    }
}

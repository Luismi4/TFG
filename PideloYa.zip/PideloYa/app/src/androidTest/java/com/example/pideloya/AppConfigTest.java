package com.example.pideloya;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AppConfigTest {

    @Test
    public void testGetBaseUrl() {
        String expectedBaseUrl = "http://192.168.0.11/tf_bares/apirest/";
        String actualBaseUrl = AppConfig.getBaseUrl();
        assertEquals(expectedBaseUrl, actualBaseUrl);
    }
}
package com.example.pideloya;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.widget.Button;
import android.widget.EditText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class registrarseTest {

    @Rule
    public ActivityScenarioRule<registrarse> activityRule = new ActivityScenarioRule<>(registrarse.class);

    private EditText etNombre;
    private EditText etUsuario;
    private EditText etCorreo;
    private EditText etDNI;
    private EditText etContrasena;
    private Button btnRegistrar;

    @Before
    public void setUp() {
        Intents.init();
        // Obtener referencias a los elementos de la interfaz de usuario
        ActivityScenario<registrarse> scenario = activityRule.getScenario();
        scenario.onActivity(activity -> {
            etNombre = activity.findViewById(R.id.editTextNombre);
            etUsuario = activity.findViewById(R.id.editTextUsuario);
            etCorreo = activity.findViewById(R.id.correo);
            etDNI = activity.findViewById(R.id.editTextDNI);
            etContrasena = activity.findViewById(R.id.editTextContrasena);
            btnRegistrar = activity.findViewById(R.id.buttonRegistrar);
        });
    }

    @After
    public void tearDown() {
        Intents.release();
    }

    @Test
    public void testRegistroUsuario() {
        // Verificar que los elementos de la interfaz de usuario estén visibles
        Espresso.onView(ViewMatchers.withId(R.id.editTextNombre)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.editTextUsuario)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.correo)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.editTextDNI)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.editTextContrasena)).check(matches(isDisplayed()));
        Espresso.onView(ViewMatchers.withId(R.id.buttonRegistrar)).check(matches(isDisplayed()));

        // Realizar acciones en los EditTexts
        Espresso.onView(withId(R.id.editTextNombre)).perform(ViewActions.replaceText("Nombre"));
        Espresso.onView(withId(R.id.editTextUsuario)).perform(ViewActions.replaceText("Usuario"));
        Espresso.onView(withId(R.id.correo)).perform(ViewActions.replaceText("correo@example.com"));
        Espresso.onView(withId(R.id.editTextDNI)).perform(ViewActions.replaceText("12345678A"));
        Espresso.onView(withId(R.id.editTextContrasena)).perform(ViewActions.replaceText("contraseña"));

        // Hacer clic en el botón "Registrar"
        Espresso.onView(withId(R.id.buttonRegistrar)).perform(ViewActions.click());
    }
}


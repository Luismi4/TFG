package com.example.pideloya;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class DBHelperTest {

    private Context context;
    private DBHelper dbHelper;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        dbHelper = new DBHelper(context);
        dbHelper.getWritableDatabase(); // Esto activará onCreate y configurará la base de datos
    }

    @After
    public void tearDown() {
        context.deleteDatabase(DBHelper.DATABASE_NAME);
    }

    @Test
    public void testDatabaseCreation() {
        SQLiteDatabase db = null;
        try {
            db = dbHelper.getReadableDatabase();
            assertTrue(db.isOpen());
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    @Test
    public void testTableLocales() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='" + DBHelper.TABLE_LOCALES + "'", null);
        boolean tableExists = cursor.getCount() > 0;
        cursor.close();
        db.close();

        assertTrue(tableExists);
    }

    @Test
    public void testGetAllBars() {
        List<ListElement> bars = dbHelper.getAllBars();
        assertEquals(3, bars.size());

        ListElement bar1 = bars.get(0);
        assertEquals("chino", bar1.getNombre());
        assertEquals("Sevilla", bar1.getCiudad());

        ListElement bar2 = bars.get(1);
        assertEquals("limón", bar2.getNombre());
        assertEquals("Sevilla", bar2.getCiudad());

        ListElement bar3 = bars.get(2);
        assertEquals("barrabas", bar3.getNombre());
        assertEquals("Sevilla", bar3.getCiudad());
    }

    @Test
    public void testOnUpgrade() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        dbHelper.onUpgrade(db, 1, 2);

        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='" + DBHelper.TABLE_LOCALES + "'", null);
        boolean tableExists = cursor.getCount() > 0;
        cursor.close();
        db.close();

        assertTrue(tableExists);
    }
}

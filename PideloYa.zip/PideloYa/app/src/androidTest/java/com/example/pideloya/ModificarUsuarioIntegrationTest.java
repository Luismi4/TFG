package com.example.pideloya;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

import android.widget.EditText;

import androidx.test.rule.ActivityTestRule;

import com.android.volley.RequestQueue;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class ModificarUsuarioIntegrationTest {

    @Mock
    private RequestQueue requestQueue;

    @Mock
    private EditText etNombre, etCorreo, etDNI, etContrasena;

    @Rule
    public ActivityTestRule<ModificarUsuarioActivity> activityRule = new ActivityTestRule<>(ModificarUsuarioActivity.class);

    @Before
    public void setUp() {
        // Inicializar los mocks
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testModificarDatosUsuario() throws Exception {
        // Obtener la actividad
        ModificarUsuarioActivity modificarUsuarioActivity = activityRule.getActivity();

        // Verificar que la actividad no sea nula
        if (modificarUsuarioActivity != null) {
            // Asignar los mocks a los campos de la actividad
            modificarUsuarioActivity.requestQueue = requestQueue;
            modificarUsuarioActivity.etNombre = etNombre;
            modificarUsuarioActivity.etCorreo = etCorreo;
            modificarUsuarioActivity.etDNI = etDNI;
            modificarUsuarioActivity.etContrasena = etContrasena;

            // Simular datos de entrada
            String nombre = "John Doe";
            String correo = "john@example.com";
            String dni = "12345678A";
            String contrasena = "password";

            // Configurar los mocks para los EditText
            etNombre.setText(nombre);
            etCorreo.setText(correo);
            etDNI.setText(dni);
            etContrasena.setText(contrasena);

            // Verificar que la actividad está en primer plano antes de realizar la prueba
            activityRule.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Ejecutar el método a probar en el hilo principal
                    try {
                        modificarUsuarioActivity.modificarDatosUsuario();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            // Esperar un momento para que se realicen las operaciones asincrónicas, si las hay
            Thread.sleep(2000);

            // Verificar que se haya creado correctamente el objeto JSON
            JSONObject expectedPostData = new JSONObject();
            expectedPostData.put("Nombre", nombre);
            expectedPostData.put("Correo", correo);
            expectedPostData.put("DNI", dni);
            expectedPostData.put("Contrasena", contrasena);

            // Verificar que se haya agregado la solicitud al RequestQueue
            verify(requestQueue).add(any());
        }
    }
}
